Welcome to the G2 coding challenge!

To run this app, first open g2backend by running 'rails s'.
The API for the backend should be visible at localhost:3000/members.

Next, open g2frontend with 'yarn start'.  It will prompt you to run the app on a different server, as the localhost is being utilized by the backend.   Simply respond 'yes' and navigate to /roster.

There you should find a list of G2 company members along with title, bio, a picture, and a voting button.  

These apps were created with a Ruby on Rails backend and a React-Redux frontend.   Thanks for checking it out!