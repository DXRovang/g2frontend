import React from 'react'

const Title = props =>{

    
    return(
      <h1 className="title">G2 Crowd Team Roster!</h1>
    )
  }

  export default Title