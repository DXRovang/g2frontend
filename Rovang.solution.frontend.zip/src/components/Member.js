import React from 'react'
// import {
//   Card, 
//   CardImg, 
//   CardTitle, CardText,
//   CardSubtitle, CardBody
// } from 'reactstrap';


const Member = props =>{
// let member = props.members[props.match.params.id - 1]

 
return(
    <>
    {/* {member ? 
      <Card className="card">
        {member.image_url ? 
        <CardImg top width="100%" className="image" src={member.image_url}  alt="Card image cap" /> : null}
        <CardBody className="body">
          <CardTitle tag="h5">{member.name}</CardTitle>
          <CardSubtitle tag="h6" className="mb-2 text-muted">{member.title}</CardSubtitle>
          <CardText>{member.bio}</CardText>
        </CardBody> 
      </Card> : null} */}

    </>
  )
}

export default Member