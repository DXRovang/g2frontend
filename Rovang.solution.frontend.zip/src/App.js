import React from 'react';
import MembersContainer from './containers/MembersContainer'
class App extends React.Component {

  render(){
    return (
        <MembersContainer />
    );
  }

}

export default App
